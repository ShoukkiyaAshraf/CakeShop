<?php
$host = "localhost";
$config_username = "root";
$password = "";
$db = "onlinecakeshop_v2";
$conn = mysqli_connect($host, $config_username, $password, $db);
?>